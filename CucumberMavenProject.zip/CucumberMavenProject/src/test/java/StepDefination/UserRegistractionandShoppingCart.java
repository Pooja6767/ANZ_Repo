package StepDefination;



import org.openqa.selenium.WebDriver;

import Pages.UserRegistration;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class UserRegistractionandShoppingCart {

	 static WebDriver driver;
	 static String elementValue;
	 static String productName;
	 static String password;
			
	 UserRegistration Reg =  new UserRegistration(driver);

@Given("I am on the website homepage")
public void i_am_on_the_website_homepage() {
    // Write code here that turns the phrase above into concrete actions
	Reg.invokeBrowser();
}

@When("I click on Sign in on the landing page and Register button")
public void i_click_on_on_the_landing_page() {
	Reg.navRegistrationPage();
}

@When("I create an account with a random email address and personal information")
public void i_create_an_account_with_a_random_email_address() {
    // Write code here that turns the phrase above into concrete actions
	  // Generate a random email address for registration
	 Reg.createAccount();
}



@When("I click on the Continue button")
public void i_click_on_the_button() {
	Reg.navAccountHomePage();
}

@Then("I should see my correct name and surname displayed on the landing screen")
public void i_should_see_my_correct_name_and_surname_displayed_on_the_landing_screen() {
	Reg.verifyUserDetails();
}

@When("I add a product to the cart")
public void i_add_a_product_to_the_cart() throws InterruptedException {
	Reg.addProductToCart();
		
}

@When("I proceed to the checkout page")
public void i_proceed_to_the_checkout_page() {
Reg.navCheckoutPage();
	
}

@When("I continue until the payment page")
public void i_continue_until_the_payment_page() {
	Reg.navPaymentPage();
}


@Then("I should see that the product details are correct on the payments page")
public void i_should_see_that_the_product_details_are_correct_on_the_payments_page() throws InterruptedException {
	
	Reg.verifyProductDetails();
}




}
