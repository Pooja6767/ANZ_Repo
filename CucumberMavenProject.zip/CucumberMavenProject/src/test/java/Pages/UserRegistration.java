package Pages;

import java.io.File;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import junit.framework.Assert;



public class UserRegistration {
	

		WebDriver driver;
		static String elementValue;
		 static String productName;
		 static String password;
		
		public UserRegistration(WebDriver driver) {
			this.driver=driver;
		}
		
	
		
		By signInButton = By.xpath("//*[@id='customer_menu_top']/li/a");
		By RegisterBtn = By.xpath("//*[@id='accountFrm']/fieldset/button");
		By frtname = By.xpath("//*[@id='AccountFrm_firstname']");
		By lstname = By.xpath("//*[@id='AccountFrm_lastname']");
		
		
		By emailInput = By.xpath("//*[@id='AccountFrm_email']");
	
		
		By Adrln1 = By.xpath("//*[@id='AccountFrm_address_1']");
		By city = By.xpath("  //*[@id='AccountFrm_city']");
		By state = By.xpath("//*[@id='AccountFrm_zone_id']");
		
		By zipcode = By.xpath("//*[@id='AccountFrm_postcode']");
		By loginNm = By.xpath("//*[@id='AccountFrm_loginname']");
		
		By logpass = By.xpath("//*[@id='AccountFrm_password']");
		
		By Confirmpass =By.xpath("//*[@id='AccountFrm_confirm']");
		By privCheck = By.xpath("//*[@id='AccountFrm_agree']");
		
		By ctnBtn = By.xpath("//*[@id='AccountFrm']/div[5]/div/div/button");
		By usrnm = By.xpath("//*[@id='customer_menu_top']/li/a/div");
		
		By prodtype = By.xpath("//*[@id='categorymenu']/nav/ul/li[7]/a");
		By subType = By.xpath("//div[@class='subcategories']//parent::li/a[contains(text(),'Conditioner')]");
		
		By chkbtn = By.xpath("(//div[@class='fixed']/a)[2]");
		
		By prodname =By.xpath("//h1[@class='productname']/span");
		By chkbtn1 = By.xpath("//div[@class='mt20 ']/ul/li/a");
		
		
		By checkout =By.xpath("//*[@id='cart_checkout1']");
		By prodExp = By.xpath("//*[@id='maincontainer']/div/div[1]/div/div[2]/table[3]/tbody/tr/td[2]/a");
		
		public void invokeBrowser() {
			System.setProperty("webdriver.chrome.driver", "Documents/chromedriver.exe");

			  // Initialize the WebDriver
			   driver = new ChromeDriver();

			
			      // Navigate to the website
			      driver.get("https://automationteststore.com/");
			     
			      driver.manage().window().maximize();
					
					
					System.out.println("Step 1: Website launched successfully and landed to website home page");
		}
		
		public void navRegistrationPage() {
			try {
				
				  driver.findElement(signInButton).click();
			       
			  
			       driver.findElement(RegisterBtn).click();
			       System.out.println("Step 2: Clicked on Sign in and Register button");
						Thread.sleep(3000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		}
		
		public void createAccount() {
			String email = "testuser" + System.currentTimeMillis() + "@example.com";
		    String fname= getRandomString(5);
		    String lname=getRandomString(5);
		    String adr1="random lane";
		    elementValue = fname;
		    // Enter email address and click "Create an Account"
		    driver.findElement(frtname).sendKeys(fname);
		    
		    driver.findElement(lstname).sendKeys(lname);
		   
		    driver.findElement(emailInput).sendKeys(email);
		 
		    driver.findElement(Adrln1).sendKeys(adr1);
		    
		    driver.findElement(city).sendKeys("Grangetown");
		    WebElement d =  driver.findElement(state);
		    Select selectBox = new Select(d);
		
			selectBox.selectByVisibleText("Cardiff");
			
			
			 driver.findElement(zipcode).sendKeys("TS6");
	
			 driver.findElement(loginNm).sendKeys(getRandomString(8));
			 
			  driver.findElement(logpass).sendKeys("556715");
			 
			 driver.findElement(Confirmpass).sendKeys("556715");
			  
			 driver.findElement(privCheck).click();
			
			 
			 System.out.println("Step 3: User able to create account with Random email and details");

		}
		
		public void navAccountHomePage() {
	
			 driver.findElement(ctnBtn).click();

			 System.out.println("Step 4: User able to click on continue button");
		}
		
		public void verifyUserDetails() {
			WebElement usnm =  driver.findElement(usrnm);
			 String output=usnm.getText();
			 String Final=output.substring(13);
			 Assert.assertEquals(Final, elementValue);
			 System.out.println("Step 5: User able to validate correct name on the landing page");
		}
		
		public void addProductToCart() {
			WebElement pdtyp =  driver.findElement(prodtype);
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds((10)));// added because of selenium 4.4
				if ((pdtyp != null)) {
					Actions act = new Actions(driver);
					wait.until(ExpectedConditions.visibilityOf(pdtyp));
					act.moveToElement(pdtyp).perform();
				}
				 
				 driver.findElement(subType).click();
			
				
				 driver.findElement(chkbtn).click();
				 
				 WebElement pr=driver.findElement(prodname); 
				 wait.until(ExpectedConditions.visibilityOf(pr));
				 productName=pr.getText();
				 System.out.println("Step 6: User able to add product to cart");
		}
		
		public void navCheckoutPage() {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds((6)));
			 WebElement chk=driver.findElement(chkbtn1); 
			 wait.until(ExpectedConditions.visibilityOf(chk));
			 chk.click();
			 System.out.println("Step 7: User proceeds to checkout page");
		}
		
		public void navPaymentPage() {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds((6)));
			 WebElement chks=driver.findElement(checkout); 
			 wait.until(ExpectedConditions.visibilityOf(chks));
			 chks.click();
			 System.out.println("Step 8: User is able to proceed till the checkout page");
		}
		
		public void verifyProductDetails() {
			 String prodEx=driver.findElement(prodExp).getText();
			 Assert.assertEquals(productName, prodEx);
			 driver.quit();
			 System.out.println("Step 9: User able to verify product details on payments page");
		}
	
		
public static String getRandomString(int length) {
	String AlphaNumericString = "abcdefghijklmnopqrstuvxyz";
	StringBuilder sb = new StringBuilder(length);
	for (int i = 0; i < length; i++) {
		int index = (int) (AlphaNumericString.length() * Math.random());
		sb.append(AlphaNumericString.charAt(index));
	}
	return sb.toString();
}

}
